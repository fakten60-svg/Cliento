package com.slither.cyemer.gui.new_ui;

import com.slither.cyemer.module.Category;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;

@Environment(EnvType.CLIENT)
public class CategoryTab {
   public final Category category;
   private final String iconFileName;

   public CategoryTab(Category category) {
      this.category = category;
      this.iconFileName = this.resolveFileName();
   }

   private String resolveFileName() {
      String var10000;
      switch(this.category) {
      case CLIENT:
         var10000 = "client.png";
         break;
      case MISC:
         var10000 = "misc.png";
         break;
      case RENDER:
         var10000 = "render.png";
         break;
      case COMBAT:
         var10000 = "combat.png";
         break;
      case MOVEMENT:
         var10000 = "movement.png";
         break;
      case PLAYER:
         var10000 = "player.png";
         break;
      default:
         var10000 = this.category.name().toLowerCase() + ".png";
      }

      return var10000;
   }

   public int getResolvedIconId() {
      return this.iconFileName == null ? -1 : (Integer)ClickGUIIconCache.globalIconIds.getOrDefault(this.iconFileName, -1);
   }

   public static class_1011 scaleImageStatic(class_1011 original, int targetSize) {
      class_1011 scaled = new class_1011(targetSize, targetSize, false);

      for(int py = 0; py < targetSize; ++py) {
         for(int px = 0; px < targetSize; ++px) {
            float srcX = ((float)px + 0.5F) / (float)targetSize * (float)original.method_4307() - 0.5F;
            float srcY = ((float)py + 0.5F) / (float)targetSize * (float)original.method_4323() - 0.5F;
            int x0 = Math.max(0, (int)Math.floor((double)srcX));
            int y0 = Math.max(0, (int)Math.floor((double)srcY));
            int x1 = Math.min(original.method_4307() - 1, x0 + 1);
            int y1 = Math.min(original.method_4323() - 1, y0 + 1);
            float fx = srcX - (float)Math.floor((double)srcX);
            float fy = srcY - (float)Math.floor((double)srcY);
            int c00 = original.method_61940(x0, y0);
            int c10 = original.method_61940(x1, y0);
            int c01 = original.method_61940(x0, y1);
            int c11 = original.method_61940(x1, y1);
            int a = (int)lerp(lerp((float)argbA(c00), (float)argbA(c10), fx), lerp((float)argbA(c01), (float)argbA(c11), fx), fy);
            int r = (int)lerp(lerp((float)argbR(c00), (float)argbR(c10), fx), lerp((float)argbR(c01), (float)argbR(c11), fx), fy);
            int g = (int)lerp(lerp((float)argbG(c00), (float)argbG(c10), fx), lerp((float)argbG(c01), (float)argbG(c11), fx), fy);
            int b = (int)lerp(lerp((float)argbB(c00), (float)argbB(c10), fx), lerp((float)argbB(c01), (float)argbB(c11), fx), fy);
            scaled.method_61941(px, py, a << 24 | r << 16 | g << 8 | b);
         }
      }

      return scaled;
   }

   private static float lerp(float a, float b, float t) {
      return a + (b - a) * t;
   }

   private static int argbA(int argb) {
      return argb >> 24 & 255;
   }

   private static int argbR(int argb) {
      return argb >> 16 & 255;
   }

   private static int argbG(int argb) {
      return argb >> 8 & 255;
   }

   private static int argbB(int argb) {
      return argb & 255;
   }
}
