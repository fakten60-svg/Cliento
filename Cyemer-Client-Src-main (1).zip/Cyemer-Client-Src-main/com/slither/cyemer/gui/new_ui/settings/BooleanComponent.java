package com.slither.cyemer.gui.new_ui.settings;

import com.slither.cyemer.module.BooleanSetting;
import com.slither.cyemer.module.implementation.ClickGUIModule;
import com.slither.cyemer.util.GuiShaderStyle;
import com.slither.cyemer.util.Renderer;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class BooleanComponent extends SettingComponent {
   private double toggleAnimation = 0.0D;

   public BooleanComponent(BooleanSetting setting) {
      super(setting);
      this.toggleAnimation = setting.isEnabled() ? 1.0D : 0.0D;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta, double alpha) {
      BooleanSetting boolSet = (BooleanSetting)this.setting;
      double dt = Math.max(0.001D, Math.min((double)delta, 0.05D));
      double target = boolSet.isEnabled() ? 1.0D : 0.0D;
      this.toggleAnimation += (target - this.toggleAnimation) * (1.0D - Math.exp(-30.0D * dt));
      if (Math.abs(this.toggleAnimation - target) < 0.001D) {
         this.toggleAnimation = target;
      }

      Color bgColor = ClickGUIModule.getColor(ClickGUIModule.getSettingsBackground(), alpha * 0.3D);
      Renderer.get().drawRoundedRectStyled(context, (float)this.x, (float)this.y, (float)this.width, (float)this.height, 4.0F, bgColor, GuiShaderStyle.ROW);
      Color textColor = ClickGUIModule.getColor(ClickGUIModule.getSettingsText(), alpha);
      float fontSize = 9.0F;
      float textY = (float)(this.y + (this.height - (double)Renderer.get().getTextHeight(fontSize)) / 2.0D);
      Renderer.get().drawText(context, this.setting.getName(), (float)this.x + 6.0F, textY, fontSize, textColor, false);
      float trackWidth = 28.0F;
      float trackHeight = 11.0F;
      float trackX = (float)(this.x + this.width - (double)trackWidth - 6.0D);
      float trackY = (float)(this.y + (this.height - (double)trackHeight) / 2.0D);
      float trackRadius = trackHeight / 2.0F;
      Color trackOff = ClickGUIModule.getColor(ClickGUIModule.getSettingsBackground(), alpha * 0.8D);
      Color trackOn = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledGradientStart(), alpha);
      Color trackColor = lerpColor(trackOff, trackOn, this.toggleAnimation);
      Renderer.get().drawRoundedRectStyled(context, trackX, trackY, trackWidth, trackHeight, trackRadius, trackColor, GuiShaderStyle.CONTROL);
      float handleSize = 7.0F;
      float handlePadding = 2.0F;
      float handleX = trackX + handlePadding + (float)(this.toggleAnimation * (double)(trackWidth - handleSize - handlePadding * 2.0F));
      float handleY = trackY + (trackHeight - handleSize) / 2.0F;
      float handleRadius = handleSize / 2.0F;
      Color handle;
      if (ClickGUIModule.useShadows() && this.toggleAnimation > 0.1D && alpha > 0.1D) {
         handle = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledGradientEnd(), alpha);
         Color glowColor = new Color(handle.getRed(), handle.getGreen(), handle.getBlue(), clampAlpha((int)(40.0D * alpha * this.toggleAnimation)));
         Renderer.get().drawGlowingRect(context, handleX, handleY, handleSize, handleSize, handleRadius, glowColor, new Color(0, 0, 0, 0), 4.0F);
      }

      handle = new Color(255, 255, 255, clampAlpha((int)(255.0D * alpha)));
      Renderer.get().drawRoundedRectStyled(context, handleX, handleY, handleSize, handleSize, handleRadius, handle, GuiShaderStyle.CONTROL);
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         ((BooleanSetting)this.setting).toggle();
      }

   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
   }

   public double getComponentHeight() {
      return 16.0D;
   }

   private static Color lerpColor(Color a, Color b, double t) {
      double c = Math.max(0.0D, Math.min(1.0D, t));
      return new Color(clampAlpha((int)((double)a.getRed() + (double)(b.getRed() - a.getRed()) * c)), clampAlpha((int)((double)a.getGreen() + (double)(b.getGreen() - a.getGreen()) * c)), clampAlpha((int)((double)a.getBlue() + (double)(b.getBlue() - a.getBlue()) * c)), clampAlpha((int)((double)a.getAlpha() + (double)(b.getAlpha() - a.getAlpha()) * c)));
   }

   private static int clampAlpha(int v) {
      return Math.max(0, Math.min(255, v));
   }
}
