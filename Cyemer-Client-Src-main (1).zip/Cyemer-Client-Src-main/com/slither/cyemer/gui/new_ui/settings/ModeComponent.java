package com.slither.cyemer.gui.new_ui.settings;

import com.slither.cyemer.module.ModeSetting;
import com.slither.cyemer.module.implementation.ClickGUIModule;
import com.slither.cyemer.util.GuiShaderStyle;
import com.slither.cyemer.util.Renderer;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public class ModeComponent extends SettingComponent {
   private static final float MODE_FONT_SIZE = 9.0F;
   private static final double MODE_HORIZONTAL_PADDING = 5.0D;
   private static final double MODE_VERTICAL_PADDING = 3.0D;
   private static final double MODE_OPTION_GAP_X = 3.0D;
   private static final double MODE_OPTION_GAP_Y = 2.0D;
   private final Map<String, Double> hoverAnimations = new HashMap();
   private final Map<String, Double> selectAnimations = new HashMap();
   private double animPillX = -1.0D;
   private double animPillY = -1.0D;
   private double animPillWidth = 0.0D;
   private double animPillHeight = 0.0D;
   private boolean pillInitialized = false;

   public ModeComponent(ModeSetting setting) {
      super(setting);
      Iterator var2 = setting.getModes().iterator();

      while(var2.hasNext()) {
         String mode = (String)var2.next();
         this.hoverAnimations.put(mode, 0.0D);
         this.selectAnimations.put(mode, mode.equals(setting.getCurrentMode()) ? 1.0D : 0.0D);
      }

   }

   private double computeBoxHeight() {
      double calculatedHeight = 6.0D;
      double currentX = 0.0D;
      double availableWidth = this.width - 10.0D;
      float rowHeight = 11.0F;
      if (!((ModeSetting)this.setting).getModes().isEmpty() && !(availableWidth <= 0.0D)) {
         calculatedHeight += (double)rowHeight;

         double modeWidth;
         for(Iterator var8 = ((ModeSetting)this.setting).getModes().iterator(); var8.hasNext(); currentX += modeWidth + 3.0D) {
            String mode = (String)var8.next();
            modeWidth = (double)(Renderer.get().getTextWidth(mode, 9.0F) + 10.0F);
            if (currentX + modeWidth > availableWidth && currentX != 0.0D) {
               calculatedHeight += (double)rowHeight + 2.0D;
               currentX = 0.0D;
            }
         }

         return calculatedHeight + 0.5D;
      } else {
         return calculatedHeight + (double)rowHeight;
      }
   }

   private float[][] computeLayout(ModeSetting modeSet) {
      float fontSize = 9.0F;
      float rowHeight = fontSize + 2.0F;
      double innerX = this.x + 5.0D;
      double innerY = this.y + 3.0D;
      double optionX = innerX;
      double optionY = innerY;
      double availableWidth = this.width - 10.0D;
      String[] modes = (String[])modeSet.getModes().toArray(new String[0]);
      float[][] bounds = new float[modes.length][4];

      for(int i = 0; i < modes.length; ++i) {
         double modeWidth = (double)(Renderer.get().getTextWidth(modes[i], fontSize) + 10.0F);
         if (optionX + modeWidth > innerX + availableWidth && optionX > innerX) {
            optionY += (double)rowHeight + 2.0D;
            optionX = innerX;
         }

         bounds[i] = new float[]{(float)optionX - 2.0F, (float)optionY, (float)modeWidth, rowHeight};
         optionX += modeWidth + 3.0D;
      }

      return bounds;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta, double alpha) {
      ModeSetting modeSet = (ModeSetting)this.setting;
      double dt = Math.max(0.001D, Math.min((double)delta, 0.05D));
      String currentMode = modeSet.getCurrentMode();
      String[] modes = (String[])modeSet.getModes().toArray(new String[0]);
      float[][] bounds = this.computeLayout(modeSet);
      float boxRadius = Math.max(3.0F, Math.min(6.0F, (float)(this.getComponentHeight() * 0.25D)));
      Color boxColor = ClickGUIModule.getColor(ClickGUIModule.getSettingsBackground(), alpha * 0.6D);
      Renderer.get().drawRoundedRectStyled(context, (float)this.x, (float)this.y, (float)this.width, (float)this.getComponentHeight(), boxRadius, boxColor, GuiShaderStyle.CONTROL);
      Color boxOverlay = new Color(255, 255, 255, (int)(5.0D * alpha));
      Renderer.get().drawRoundedRectStyled(context, (float)this.x, (float)this.y, (float)this.width, (float)this.getComponentHeight(), boxRadius, boxOverlay, GuiShaderStyle.PANEL_GLASS);
      float targetPillX = -1.0F;
      float targetPillY = -1.0F;
      float targetPillW = 0.0F;
      float targetPillH = 0.0F;

      for(int i = 0; i < modes.length; ++i) {
         if (modes[i].equals(currentMode)) {
            targetPillX = bounds[i][0];
            targetPillY = bounds[i][1];
            targetPillW = bounds[i][2];
            targetPillH = bounds[i][3];
            break;
         }
      }

      float fontSize;
      if (targetPillX != -1.0F) {
         if (!this.pillInitialized) {
            this.animPillX = (double)targetPillX;
            this.animPillY = (double)targetPillY;
            this.animPillWidth = (double)targetPillW;
            this.animPillHeight = (double)targetPillH;
            this.pillInitialized = true;
         } else {
            double speed = 1.0D - Math.exp(-32.0D * dt);
            this.animPillX += ((double)targetPillX - this.animPillX) * speed;
            this.animPillY += ((double)targetPillY - this.animPillY) * speed;
            this.animPillWidth += ((double)targetPillW - this.animPillWidth) * speed;
            this.animPillHeight += ((double)targetPillH - this.animPillHeight) * speed;
         }

         fontSize = (float)this.animPillHeight / 2.0F;
         float b = 0.75F;
         Color borderColor = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledText(), alpha * 0.35D);
         Renderer.get().drawRoundedRectStyled(context, (float)this.animPillX - b, (float)this.animPillY - b, (float)this.animPillWidth + b * 2.0F, (float)this.animPillHeight + b * 2.0F, fontSize + b, borderColor, GuiShaderStyle.ROW_ENABLED);
         Color bgColor = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledText(), alpha * 0.25D);
         Renderer.get().drawRoundedRectStyled(context, (float)this.animPillX, (float)this.animPillY, (float)this.animPillWidth, (float)this.animPillHeight, fontSize, bgColor, GuiShaderStyle.ROW_ENABLED);
      }

      fontSize = 9.0F;

      for(int i = 0; i < modes.length; ++i) {
         float pillX = bounds[i][0];
         float pillY = bounds[i][1];
         float pillW = bounds[i][2];
         float pillH = bounds[i][3];
         boolean isSelected = modes[i].equals(currentMode);
         boolean isHov = (float)mouseX >= pillX && (float)mouseX <= pillX + pillW && (float)mouseY >= pillY && (float)mouseY <= pillY + pillH;
         double hTarget = isHov ? 1.0D : 0.0D;
         double hCur = (Double)this.hoverAnimations.getOrDefault(modes[i], 0.0D);
         hCur += (hTarget - hCur) * (1.0D - Math.exp(-24.0D * dt));
         this.hoverAnimations.put(modes[i], hCur);
         double sTarget = isSelected ? 1.0D : 0.0D;
         double sCur = (Double)this.selectAnimations.getOrDefault(modes[i], isSelected ? 1.0D : 0.0D);
         sCur += (sTarget - sCur) * (1.0D - Math.exp(-26.0D * dt));
         this.selectAnimations.put(modes[i], sCur);
         if (!isSelected && hCur > 0.01D) {
            Color hoverColor = ClickGUIModule.getColor(ClickGUIModule.getSettingsBackground(), alpha * 0.3D * hCur);
            Renderer.get().drawRoundedRectStyled(context, pillX, pillY, pillW, pillH, pillH / 2.0F, hoverColor, GuiShaderStyle.ROW);
         }

         double brightness = isSelected ? 1.0D : 0.6D + hCur * 0.3D + sCur * 0.4D;
         Color baseTextColor = isSelected ? ClickGUIModule.getModuleEnabledText() : ClickGUIModule.getModuleDisabledText();
         Color textColor = ClickGUIModule.getColor(baseTextColor, alpha * Math.min(1.0D, brightness));
         float textH = Renderer.get().getTextHeight(fontSize);
         float textY = pillY + (pillH - textH) / 2.0F;
         Renderer.get().drawText(context, modes[i], pillX + 5.0F, textY, fontSize, textColor, false);
      }

   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0 && this.isHovered(mouseX, mouseY)) {
         ModeSetting modeSet = (ModeSetting)this.setting;
         String[] modes = (String[])modeSet.getModes().toArray(new String[0]);
         float[][] bounds = this.computeLayout(modeSet);

         for(int i = 0; i < modes.length; ++i) {
            if (mouseX >= (double)bounds[i][0] && mouseX <= (double)(bounds[i][0] + bounds[i][2]) && mouseY >= (double)bounds[i][1] && mouseY <= (double)(bounds[i][1] + bounds[i][3])) {
               modeSet.setCurrentMode(modes[i]);
               break;
            }
         }

      }
   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
   }

   public double getComponentHeight() {
      return this.computeBoxHeight();
   }
}
