package com.slither.cyemer.gui.new_ui.settings;

import com.slither.cyemer.module.SliderSetting;
import com.slither.cyemer.module.implementation.ClickGUIModule;
import com.slither.cyemer.util.GuiShaderStyle;
import com.slither.cyemer.util.Renderer;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class SliderComponent extends SettingComponent {
   private boolean dragging = false;
   private final SliderSetting sliderSetting;
   private double displayPos;
   private double hoverAnimation = 0.0D;

   public SliderComponent(SliderSetting setting) {
      super(setting);
      this.sliderSetting = setting;
      double range = setting.getMax() - setting.getMin();
      this.displayPos = range > 0.0D ? (setting.getPreciseValue() - setting.getMin()) / range : 0.0D;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta, double alpha) {
      double dt = Math.max(0.001D, Math.min((double)delta, 0.05D));
      boolean hovered = (double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= this.y - 2.0D && (double)mouseY <= this.y + this.getComponentHeight() + 2.0D;
      double hoverTarget = !hovered && !this.dragging ? 0.0D : 1.0D;
      this.hoverAnimation += (hoverTarget - this.hoverAnimation) * (1.0D - Math.exp(-24.0D * dt));
      float handleSize = 7.0F + (float)(this.hoverAnimation * 1.600000023841858D);
      float handleRadius = handleSize / 2.0F;
      double paddedWidth = this.width - (double)handleSize;
      double range;
      double trueFill;
      if (this.dragging && paddedWidth > 0.0D) {
         range = ((double)mouseX - (this.x + (double)handleSize / 2.0D)) / paddedWidth;
         trueFill = this.sliderSetting.getMin() + class_3532.method_15350(range, 0.0D, 1.0D) * (this.sliderSetting.getMax() - this.sliderSetting.getMin());
         this.sliderSetting.setValue(trueFill);
      }

      range = this.sliderSetting.getMax() - this.sliderSetting.getMin();
      trueFill = range > 0.0D ? (this.sliderSetting.getPreciseValue() - this.sliderSetting.getMin()) / range : 0.0D;
      double animSpeed = this.dragging ? 45.0D : 30.0D;
      this.displayPos += (trueFill - this.displayPos) * (1.0D - Math.exp(-animSpeed * dt));
      float centerY = (float)(this.y + this.getComponentHeight() / 2.0D);
      float trackHeight = 3.5F + (float)(this.hoverAnimation * 1.0D);
      float trackRadius = trackHeight / 2.0F;
      float trackY = centerY - trackHeight / 2.0F;
      Color trackColor = ClickGUIModule.getColor(ClickGUIModule.getSettingsBackground(), alpha * (0.72D + this.hoverAnimation * 0.08D));
      Renderer.get().drawRoundedRectStyled(context, (float)this.x, trackY, (float)this.width, trackHeight, trackRadius, trackColor, GuiShaderStyle.CONTROL);
      double fillW = (double)handleSize / 2.0D + paddedWidth * this.displayPos;
      if (fillW > 1.0D) {
         Color gradStart = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledGradientStart(), alpha);
         Color gradEnd = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledGradientEnd(), alpha);
         Renderer.get().drawRoundedRectGradientStyled(context, (float)this.x, trackY, (float)fillW, trackHeight, trackRadius, gradStart, gradEnd, false, GuiShaderStyle.CONTROL);
      }

      double handleX = this.x + paddedWidth * this.displayPos;
      float handleY = centerY - handleSize / 2.0F;
      Color handle;
      if ((this.hoverAnimation > 0.15D || this.dragging) && alpha > 0.1D) {
         handle = ClickGUIModule.getColor(ClickGUIModule.getModuleEnabledGradientEnd(), alpha);
         int glowA = Math.max(0, Math.min(255, (int)(60.0D * alpha * this.hoverAnimation)));
         Color glowColor = new Color(handle.getRed(), handle.getGreen(), handle.getBlue(), glowA);
         Renderer.get().drawGlowingRect(context, (float)handleX, handleY, handleSize, handleSize, handleRadius, glowColor, new Color(0, 0, 0, 0), 5.0F);
      }

      handle = new Color(255, 255, 255, Math.max(0, Math.min(255, (int)(255.0D * alpha))));
      Renderer.get().drawRoundedRectStyled(context, (float)handleX, handleY, handleSize, handleSize, handleRadius, handle, GuiShaderStyle.CONTROL);
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         this.dragging = true;
      }

   }

   public void mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.dragging = false;
      }

   }

   public double getComponentHeight() {
      return 7.0D;
   }
}
