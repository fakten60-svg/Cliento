package com.slither.cyemer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.slither.cyemer.Cyemer;
import com.slither.cyemer.gui.new_ui.ClickGUI;
import com.slither.cyemer.gui.new_ui.FriendlistPanel;
import com.slither.cyemer.gui.new_ui.old.Panel;
import com.slither.cyemer.hud.HUDElement;
import com.slither.cyemer.module.BooleanSetting;
import com.slither.cyemer.module.ColorSetting;
import com.slither.cyemer.module.ModeSetting;
import com.slither.cyemer.module.Module;
import com.slither.cyemer.module.Setting;
import com.slither.cyemer.module.SliderSetting;
import com.slither.cyemer.module.StringSetting;
import com.slither.cyemer.theme.ThemeManager;
import java.awt.Color;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;

@Environment(EnvType.CLIENT)
public class ConfigManager {
   private static final int CONFIG_AUTH_GATE_SALT = 1094866261;
   private final Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
   private final File configsDir = new File(FabricLoader.getInstance().getConfigDir().toFile(), "cyemer/configs");
   private Map<String, ConfigManager.PanelPosition> panelPositions = new HashMap();
   private static final ConfigManager INSTANCE = new ConfigManager();

   public static ConfigManager getInstance() {
      return INSTANCE;
   }

   public ConfigManager() {
      if (!this.configsDir.exists()) {
         this.configsDir.mkdirs();
      }

   }

   public void load(String name) {
      File configFile = new File(this.configsDir, name + ".json");
      if (!configFile.exists()) {
         if ("default".equals(name)) {
            ThemeManager.getInstance().setCurrentTheme("dark");
            this.save("default", new ArrayList());
         }

      } else {
         try {
            FileReader reader = new FileReader(configFile);

            label62: {
               try {
                  ConfigManager.ConfigData data = (ConfigManager.ConfigData)this.gson.fromJson(reader, ConfigManager.ConfigData.class);
                  if (data == null) {
                     break label62;
                  }

                  this.applyConfig(data);
                  this.panelPositions = (Map)(data.panelPositions != null ? data.panelPositions : new HashMap());
               } catch (Throwable var7) {
                  try {
                     reader.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }

                  throw var7;
               }

               reader.close();
               return;
            }

            reader.close();
         } catch (Exception var8) {
         }
      }
   }

   public void loadModule(String configName, Module module) {
      if (configName != null && !configName.isEmpty() && module != null) {
         if (!"Booster".equalsIgnoreCase(module.getName())) {
            File configFile = new File(this.configsDir, configName + ".json");
            if (configFile.exists()) {
               try {
                  FileReader reader = new FileReader(configFile);

                  label65: {
                     label64: {
                        try {
                           ConfigManager.ConfigData data = (ConfigManager.ConfigData)this.gson.fromJson(reader, ConfigManager.ConfigData.class);
                           if (data == null || data.modules == null) {
                              break label64;
                           }

                           Map<String, ConfigManager.ModuleData> moduleLookup = this.buildModuleLookup(data.modules);
                           ConfigManager.ModuleData moduleData = this.resolveModuleData(data.modules, moduleLookup, module.getName());
                           if (moduleData != null) {
                              module.setEnabled(moduleData.enabled);
                              module.setKeyCode(moduleData.keyCode);
                              if (moduleData.settings == null) {
                                 break label65;
                              }

                              Iterator var8 = module.getSettings().iterator();

                              while(true) {
                                 if (!var8.hasNext()) {
                                    break label65;
                                 }

                                 Setting setting = (Setting)var8.next();
                                 this.loadSetting(moduleData.settings, setting);
                              }
                           }
                        } catch (Throwable var11) {
                           try {
                              reader.close();
                           } catch (Throwable var10) {
                              var11.addSuppressed(var10);
                           }

                           throw var11;
                        }

                        reader.close();
                        return;
                     }

                     reader.close();
                     return;
                  }

                  reader.close();
               } catch (Exception var12) {
               }

            }
         }
      }
   }

   public void save(String name, List<Panel> panels) {
      File configFile = new File(this.configsDir, name + ".json");
      ConfigManager.ConfigData data = new ConfigManager.ConfigData();
      data.theme = ThemeManager.getInstance().getCurrentTheme().name;
      data.hudElements = new HashMap();
      Iterator var5;
      HUDElement element;
      ConfigManager.HUDElementData elementData;
      if (Cyemer.INSTANCE != null && Cyemer.INSTANCE.getHudManager() != null) {
         for(var5 = Cyemer.INSTANCE.getHudManager().getElements().iterator(); var5.hasNext(); data.hudElements.put(element.getName(), elementData)) {
            element = (HUDElement)var5.next();
            elementData = new ConfigManager.HUDElementData(element.getX(), element.getY(), element.isEnabled());
            elementData.settings = new JsonObject();
            List<Setting> settings = element.getSettings();
            if (settings != null) {
               Iterator var9 = settings.iterator();

               while(var9.hasNext()) {
                  Setting setting = (Setting)var9.next();
                  this.saveSetting(elementData.settings, setting);
               }
            }
         }
      }

      data.modules = new HashMap();
      var5 = Cyemer.INSTANCE.getModuleManager().getModules().iterator();

      while(true) {
         Module module;
         do {
            if (!var5.hasNext()) {
               if (panels != null) {
                  data.panelPositions = new HashMap();

                  Panel var16;
                  for(var5 = panels.iterator(); var5.hasNext(); var16 = (Panel)var5.next()) {
                  }
               } else {
                  data.panelPositions = this.panelPositions;
               }

               data.cameraX = ClickGUI.cameraX;
               data.cameraY = ClickGUI.cameraY;
               data.zoom = ClickGUI.zoom;
               this.panelPositions = data.panelPositions;

               try {
                  FileWriter writer = new FileWriter(configFile);

                  try {
                     this.gson.toJson(data, writer);
                  } catch (Throwable var12) {
                     try {
                        writer.close();
                     } catch (Throwable var11) {
                        var12.addSuppressed(var11);
                     }

                     throw var12;
                  }

                  writer.close();
               } catch (IOException var13) {
               }

               return;
            }

            module = (Module)var5.next();
         } while("Booster".equalsIgnoreCase(module.getName()));

         ConfigManager.ModuleData moduleData = new ConfigManager.ModuleData();
         moduleData.enabled = module.isEnabledRaw();
         moduleData.keyCode = module.getKeyCode();
         moduleData.settings = new JsonObject();
         Iterator var18 = module.getSettings().iterator();

         while(var18.hasNext()) {
            Setting setting = (Setting)var18.next();
            this.saveSetting(moduleData.settings, setting);
         }

         data.modules.put(module.getName(), moduleData);
      }
   }

   public void save(String name, List<Panel> panels, FriendlistPanel friendlistPanel) {
      File configFile = new File(this.configsDir, name + ".json");
      ConfigManager.ConfigData data = new ConfigManager.ConfigData();
      data.theme = ThemeManager.getInstance().getCurrentTheme().name;
      data.hudElements = new HashMap();
      Iterator var6;
      HUDElement element;
      ConfigManager.HUDElementData elementData;
      if (Cyemer.INSTANCE != null && Cyemer.INSTANCE.getHudManager() != null) {
         for(var6 = Cyemer.INSTANCE.getHudManager().getElements().iterator(); var6.hasNext(); data.hudElements.put(element.getName(), elementData)) {
            element = (HUDElement)var6.next();
            elementData = new ConfigManager.HUDElementData(element.getX(), element.getY(), element.isEnabled());
            elementData.settings = new JsonObject();
            List<Setting> settings = element.getSettings();
            if (settings != null) {
               Iterator var10 = settings.iterator();

               while(var10.hasNext()) {
                  Setting setting = (Setting)var10.next();
                  this.saveSetting(elementData.settings, setting);
               }
            }
         }
      }

      data.modules = new HashMap();
      var6 = Cyemer.INSTANCE.getModuleManager().getModules().iterator();

      while(true) {
         Module module;
         do {
            if (!var6.hasNext()) {
               if (panels != null) {
                  data.panelPositions = new HashMap();

                  Panel var17;
                  for(var6 = panels.iterator(); var6.hasNext(); var17 = (Panel)var6.next()) {
                  }

                  if (friendlistPanel != null) {
                     data.panelPositions.put("FRIENDLIST", new ConfigManager.PanelPosition(friendlistPanel.getX(), friendlistPanel.getY()));
                  }
               } else {
                  data.panelPositions = this.panelPositions;
               }

               data.cameraX = ClickGUI.cameraX;
               data.cameraY = ClickGUI.cameraY;
               data.zoom = ClickGUI.zoom;
               this.panelPositions = data.panelPositions;

               try {
                  FileWriter writer = new FileWriter(configFile);

                  try {
                     this.gson.toJson(data, writer);
                  } catch (Throwable var13) {
                     try {
                        writer.close();
                     } catch (Throwable var12) {
                        var13.addSuppressed(var12);
                     }

                     throw var13;
                  }

                  writer.close();
               } catch (IOException var14) {
               }

               return;
            }

            module = (Module)var6.next();
         } while("Booster".equalsIgnoreCase(module.getName()));

         ConfigManager.ModuleData moduleData = new ConfigManager.ModuleData();
         moduleData.enabled = module.isEnabledRaw();
         moduleData.keyCode = module.getKeyCode();
         moduleData.settings = new JsonObject();
         Iterator var19 = module.getSettings().iterator();

         while(var19.hasNext()) {
            Setting setting = (Setting)var19.next();
            this.saveSetting(moduleData.settings, setting);
         }

         data.modules.put(module.getName(), moduleData);
      }
   }

   private void saveSetting(JsonObject jsonObject, Setting setting) {
      if (setting instanceof ModeSetting) {
         ModeSetting s = (ModeSetting)setting;
         jsonObject.addProperty(s.getName(), s.getCurrentMode());
      } else if (setting instanceof SliderSetting) {
         SliderSetting s = (SliderSetting)setting;
         jsonObject.addProperty(s.getName(), s.getPreciseValue());
      } else if (setting instanceof ColorSetting) {
         ColorSetting s = (ColorSetting)setting;
         jsonObject.addProperty(s.getName(), s.getValue().getRGB());
      } else if (setting instanceof BooleanSetting) {
         BooleanSetting s = (BooleanSetting)setting;
         jsonObject.addProperty(s.getName(), s.isEnabled());
      } else if (setting instanceof StringSetting) {
         StringSetting s = (StringSetting)setting;
         jsonObject.addProperty(s.getName(), s.getValue());
      }

   }

   private void loadSetting(JsonObject jsonObject, Setting setting) {
      String settingKey = this.resolveSettingKey(jsonObject, setting.getName());
      if (settingKey != null) {
         try {
            if (setting instanceof ModeSetting) {
               ModeSetting s = (ModeSetting)setting;
               s.setCurrentMode(jsonObject.get(settingKey).getAsString());
            } else if (setting instanceof SliderSetting) {
               SliderSetting s = (SliderSetting)setting;
               s.setValue(jsonObject.get(settingKey).getAsDouble());
            } else if (setting instanceof ColorSetting) {
               ColorSetting s = (ColorSetting)setting;
               s.setValue(new Color(jsonObject.get(settingKey).getAsInt(), true));
            } else if (setting instanceof BooleanSetting) {
               BooleanSetting s = (BooleanSetting)setting;
               s.setEnabled(jsonObject.get(settingKey).getAsBoolean());
            } else if (setting instanceof StringSetting) {
               StringSetting s = (StringSetting)setting;
               s.setValue(jsonObject.get(settingKey).getAsString());
            }
         } catch (Exception var9) {
         }

      }
   }

   private void applyConfig(ConfigManager.ConfigData data) {
      if (data.theme != null) {
         ThemeManager.getInstance().setCurrentTheme(data.theme);
      }

      if (data.cameraX != null) {
         ClickGUI.cameraX = data.cameraX;
      }

      if (data.cameraY != null) {
         ClickGUI.cameraY = data.cameraY;
      }

      if (data.zoom != null) {
         ClickGUI.zoom = data.zoom;
      }

      if (data.hudElements != null && Cyemer.INSTANCE != null && Cyemer.INSTANCE.getHudManager() != null) {
         Iterator var2 = data.hudElements.entrySet().iterator();

         label82:
         while(true) {
            ConfigManager.HUDElementData elementData;
            List settings;
            do {
               HUDElement element;
               do {
                  Entry entry;
                  do {
                     if (!var2.hasNext()) {
                        break label82;
                     }

                     entry = (Entry)var2.next();
                     element = Cyemer.INSTANCE.getHudManager().getElement((String)entry.getKey());
                  } while(element == null);

                  elementData = (ConfigManager.HUDElementData)entry.getValue();
                  element.setX(elementData.x);
                  element.setY(elementData.y);
                  element.setEnabled(elementData.enabled);
               } while(elementData.settings == null);

               settings = element.getSettings();
            } while(settings == null);

            Iterator var7 = settings.iterator();

            while(var7.hasNext()) {
               Setting setting = (Setting)var7.next();
               this.loadSetting(elementData.settings, setting);
            }
         }
      }

      if (data.modules != null) {
         Map<String, ConfigManager.ModuleData> moduleLookup = this.buildModuleLookup(data.modules);
         Iterator var10 = (new ArrayList(Cyemer.INSTANCE.getModuleManager().getModules())).iterator();

         while(true) {
            Module module;
            ConfigManager.ModuleData moduleData;
            do {
               do {
                  do {
                     if (!var10.hasNext()) {
                        return;
                     }

                     module = (Module)var10.next();
                  } while("Booster".equalsIgnoreCase(module.getName()));

                  moduleData = this.resolveModuleData(data.modules, moduleLookup, module.getName());
               } while(moduleData == null);

               module.setEnabled(moduleData.enabled);
               module.setKeyCode(moduleData.keyCode);
            } while(moduleData.settings == null);

            Iterator var13 = module.getSettings().iterator();

            while(var13.hasNext()) {
               Setting setting = (Setting)var13.next();
               this.loadSetting(moduleData.settings, setting);
            }
         }
      }
   }

   private Map<String, ConfigManager.ModuleData> buildModuleLookup(Map<String, ConfigManager.ModuleData> modules) {
      Map<String, ConfigManager.ModuleData> lookup = new HashMap();
      if (modules == null) {
         return lookup;
      } else {
         Iterator var3 = modules.entrySet().iterator();

         while(var3.hasNext()) {
            Entry<String, ConfigManager.ModuleData> entry = (Entry)var3.next();
            String key = (String)entry.getKey();
            ConfigManager.ModuleData value = (ConfigManager.ModuleData)entry.getValue();
            if (key != null && !key.isBlank() && value != null) {
               this.putIfAbsent(lookup, this.normalizeLookupKey(key), value);
               this.putIfAbsent(lookup, this.normalizeAliasLookupKey(key), value);
            }
         }

         return lookup;
      }
   }

   private ConfigManager.ModuleData resolveModuleData(Map<String, ConfigManager.ModuleData> modules, Map<String, ConfigManager.ModuleData> lookup, String moduleName) {
      if (modules != null && moduleName != null && !moduleName.isBlank()) {
         ConfigManager.ModuleData exact = (ConfigManager.ModuleData)modules.get(moduleName);
         if (exact != null) {
            return exact;
         } else if (lookup != null && !lookup.isEmpty()) {
            ConfigManager.ModuleData normalized = (ConfigManager.ModuleData)lookup.get(this.normalizeLookupKey(moduleName));
            return normalized != null ? normalized : (ConfigManager.ModuleData)lookup.get(this.normalizeAliasLookupKey(moduleName));
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private String resolveSettingKey(JsonObject jsonObject, String settingName) {
      if (jsonObject != null && settingName != null && !settingName.isBlank()) {
         if (jsonObject.has(settingName)) {
            return settingName;
         } else if ("Separator".equals(settingName) && jsonObject.has("Seperator")) {
            return "Seperator";
         } else {
            String normalizedTarget = this.normalizeLookupKey(settingName);
            String aliasTarget = this.normalizeAliasLookupKey(settingName);
            Iterator var5 = jsonObject.entrySet().iterator();

            String key;
            do {
               do {
                  do {
                     if (!var5.hasNext()) {
                        return null;
                     }

                     Entry<String, JsonElement> entry = (Entry)var5.next();
                     key = (String)entry.getKey();
                  } while(key == null);
               } while(key.isBlank());
            } while(!this.normalizeLookupKey(key).equals(normalizedTarget) && !this.normalizeAliasLookupKey(key).equals(aliasTarget));

            return key;
         }
      } else {
         return null;
      }
   }

   private void putIfAbsent(Map<String, ConfigManager.ModuleData> map, String key, ConfigManager.ModuleData value) {
      if (key != null && !key.isBlank() && value != null) {
         map.putIfAbsent(key, value);
      }
   }

   private String normalizeLookupKey(String value) {
      return value == null ? "" : value.trim().toLowerCase().replaceAll("[^a-z0-9]", "");
   }

   private String normalizeAliasLookupKey(String value) {
      String normalized = this.normalizeLookupKey(value);
      return normalized.startsWith("auto") && normalized.length() > 4 ? normalized.substring(4) : normalized;
   }

   public void save(String name) {
      this.save(name, (List)null);
   }

   public synchronized String exportConfigJson(String name) {
      String safeName = this.sanitizeConfigName(name);
      File configFile = new File(this.configsDir, safeName + ".json");
      if (!configFile.exists()) {
         return null;
      } else {
         try {
            return Files.readString(configFile.toPath(), StandardCharsets.UTF_8);
         } catch (IOException var5) {
            return null;
         }
      }
   }

   public synchronized boolean importConfigJson(String name, String rawJson, boolean applyNow) {
      if (rawJson != null && !rawJson.isBlank()) {
         String safeName = this.sanitizeConfigName(name);

         JsonElement parsed;
         ConfigManager.ConfigData data;
         try {
            parsed = JsonParser.parseString(rawJson);
            data = (ConfigManager.ConfigData)this.gson.fromJson(parsed, ConfigManager.ConfigData.class);
         } catch (Exception var14) {
            return false;
         }

         if (data == null) {
            return false;
         } else {
            File configFile = new File(this.configsDir, safeName + ".json");

            try {
               FileWriter writer = new FileWriter(configFile);

               try {
                  this.gson.toJson(parsed, writer);
               } catch (Throwable var12) {
                  try {
                     writer.close();
                  } catch (Throwable var11) {
                     var12.addSuppressed(var11);
                  }

                  throw var12;
               }

               writer.close();
            } catch (IOException var13) {
               return false;
            }

            if (applyNow) {
               this.applyConfig(data);
               this.panelPositions = (Map)(data.panelPositions != null ? data.panelPositions : new HashMap());
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private String sanitizeConfigName(String name) {
      if (name != null && !name.isBlank()) {
         String normalized = name.trim().replaceAll("[^A-Za-z0-9_.-]", "_");
         if (normalized.isBlank()) {
            return "default";
         } else {
            if (normalized.length() > 64) {
               normalized = normalized.substring(0, 64);
            }

            return normalized;
         }
      } else {
         return "default";
      }
   }

   public boolean delete(String name) {
      if (name != null && !name.isEmpty() && !"default".equalsIgnoreCase(name)) {
         File configFile = new File(this.configsDir, name + ".json");
         if (configFile.exists()) {
            try {
               return Files.deleteIfExists(configFile.toPath());
            } catch (IOException var4) {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public List<String> getAvailableConfigs() {
      File[] files = this.configsDir.listFiles((dir, name) -> {
         return name.toLowerCase().endsWith(".json");
      });
      return (List)(files == null ? new ArrayList() : (List)Arrays.stream(files).map((file) -> {
         return file.getName().substring(0, file.getName().length() - 5);
      }).collect(Collectors.toList()));
   }

   public Map<String, ConfigManager.PanelPosition> getPanelPositions() {
      return this.panelPositions;
   }

   @Environment(EnvType.CLIENT)
   private static class ConfigData {
      public String theme;
      public Map<String, ConfigManager.HUDElementData> hudElements = new HashMap();
      public Map<String, ConfigManager.ModuleData> modules = new HashMap();
      public Map<String, ConfigManager.PanelPosition> panelPositions = new HashMap();
      public Double cameraX;
      public Double cameraY;
      public Double zoom;
   }

   @Environment(EnvType.CLIENT)
   private static class ModuleData {
      public boolean enabled;
      public int keyCode;
      public JsonObject settings = new JsonObject();
   }

   @Environment(EnvType.CLIENT)
   private static class HUDElementData {
      public double x;
      public double y;
      public boolean enabled;
      public JsonObject settings;

      public HUDElementData(double x, double y, boolean enabled) {
         this.x = x;
         this.y = y;
         this.enabled = enabled;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class PanelPosition {
      public double x;
      public double y;

      public PanelPosition(double x, double y) {
         this.x = x;
         this.y = y;
      }
   }
}
