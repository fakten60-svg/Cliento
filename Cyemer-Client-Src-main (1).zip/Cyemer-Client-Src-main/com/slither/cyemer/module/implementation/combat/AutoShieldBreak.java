package com.slither.cyemer.module.implementation.combat;

import com.slither.cyemer.friend.FriendManager;
import com.slither.cyemer.mixin.PlayerInventoryAccessor;
import com.slither.cyemer.module.BooleanSetting;
import com.slither.cyemer.module.Category;
import com.slither.cyemer.module.Module;
import com.slither.cyemer.module.SliderSetting;
import com.slither.cyemer.util.AttackValidator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public class AutoShieldBreak extends Module {
   public static boolean breakingShield = false;
   private final SliderSetting cps = new SliderSetting("CPS", 20.0D, 1.0D, 20.0D, 0);
   private final SliderSetting reactionDelay = new SliderSetting("Reaction Delay", 0.0D, 0.0D, 250.0D, 0);
   private final SliderSetting swapDelay = new SliderSetting("Swap Delay", 50.0D, 0.0D, 500.0D, 0);
   private final SliderSetting attackDelay = new SliderSetting("Attack Delay", 50.0D, 0.0D, 500.0D, 0);
   private final SliderSetting swapBackDelay = new SliderSetting("Swap Back Delay", 100.0D, 0.0D, 500.0D, 0);
   private final BooleanSetting revertSlot = new BooleanSetting("Revert Slot", true);
   private final BooleanSetting rayTraceCheck = new BooleanSetting("Check Facing", true);
   private final BooleanSetting autoStun = new BooleanSetting("Auto Stun", true);
   private final BooleanSetting disableIfUsingItem = new BooleanSetting("Disable if using item", true);
   private final BooleanSetting ignoreFriends = new BooleanSetting("Ignore Friends", false);
   private final SliderSetting hitboxAccuracy = new SliderSetting("Hitbox Accuracy", 0.0D, 0.0D, 1.0D, 2);
   private long lastCpsMs;
   private long lastReactionMs;
   private long lastSwapMs;
   private long lastAttackMs;
   private long lastSwapBackMs;
   private int savedSlot = -1;

   public AutoShieldBreak() {
      super("AutoShieldBreak", "Automatically breaks the opponent's shield", Category.COMBAT);
      this.addSetting(this.cps);
      this.addSetting(this.reactionDelay);
      this.addSetting(this.swapDelay);
      this.addSetting(this.attackDelay);
      this.addSetting(this.swapBackDelay);
      this.addSetting(this.revertSlot);
      this.addSetting(this.rayTraceCheck);
      this.addSetting(this.autoStun);
      this.addSetting(this.disableIfUsingItem);
      this.addSetting(this.ignoreFriends);
      this.addSetting(this.hitboxAccuracy);
   }

   private boolean canRunAuto() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1755 == null) {
         int axeSlot = this.findAxe();
         if (axeSlot == -1) {
            return false;
         } else if (this.mc.field_1724.method_6115() && this.disableIfUsingItem.isEnabled()) {
            return false;
         } else {
            return System.currentTimeMillis() - this.lastCpsMs >= (long)(1000.0D / Math.max(0.1D, this.cps.getValue()));
         }
      } else {
         return false;
      }
   }

   private class_1657 getTargetPlayer() {
      if (this.mc.field_1765 != null && this.mc.field_1765.method_17783() == class_240.field_1331) {
         class_3966 hit = (class_3966)this.mc.field_1765;
         class_1297 var3 = hit.method_17782();
         if (var3 instanceof class_1657) {
            class_1657 target = (class_1657)var3;
            return this.ignoreFriends.isEnabled() && FriendManager.getInstance().isFriend(target.method_5667()) ? null : target;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private int findAxe() {
      for(int i = 0; i < 9; ++i) {
         if (this.mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1743) {
            return i;
         }
      }

      return -1;
   }

   public void onTickPost() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         class_1657 target = this.getTargetPlayer();
         boolean isBlocking;
         boolean canBreak;
         class_243 targetLook;
         if (this.savedSlot != -1 && (double)(System.currentTimeMillis() - this.lastSwapBackMs) >= this.swapBackDelay.getValue()) {
            isBlocking = false;
            if (target == null) {
               isBlocking = true;
            } else {
               canBreak = target.method_6039() && target.method_24518(class_1802.field_8255);
               boolean canBreak = true;
               if (this.rayTraceCheck.isEnabled()) {
                  targetLook = this.mc.field_1724.method_73189().method_1020(target.method_73189()).method_1029();
                  class_243 targetLook = target.method_5828(1.0F).method_1029();
                  if (targetLook.method_1026(targetLook) <= -0.6D) {
                     canBreak = false;
                  }
               }

               if (canBreak && !this.isLookingAtHitbox(target)) {
                  canBreak = false;
               }

               if (!canBreak || !canBreak) {
                  isBlocking = true;
               }
            }

            if (isBlocking) {
               if (this.revertSlot.isEnabled() && ((PlayerInventoryAccessor)this.mc.field_1724.method_31548()).getSelectedSlot() != this.savedSlot) {
                  ((PlayerInventoryAccessor)this.mc.field_1724.method_31548()).setSelectedSlot(this.savedSlot);
               }

               this.savedSlot = -1;
               breakingShield = false;
               return;
            }
         }

         if (this.canRunAuto()) {
            if (target != null) {
               isBlocking = target.method_6039() && target.method_24518(class_1802.field_8255);
               canBreak = true;
               if (this.rayTraceCheck.isEnabled()) {
                  class_243 dirToMe = this.mc.field_1724.method_73189().method_1020(target.method_73189()).method_1029();
                  targetLook = target.method_5828(1.0F).method_1029();
                  if (dirToMe.method_1026(targetLook) <= -0.6D) {
                     canBreak = false;
                  }
               }

               if (canBreak && !this.isLookingAtHitbox(target)) {
                  canBreak = false;
               }

               if (isBlocking && canBreak) {
                  if (!(this.mc.field_1724.method_6047().method_7909() instanceof class_1743)) {
                     if (System.currentTimeMillis() - this.lastReactionMs >= (long)this.reactionDelay.getValue() && System.currentTimeMillis() - this.lastSwapMs >= (long)this.swapDelay.getValue()) {
                        breakingShield = true;
                        if (this.savedSlot == -1) {
                           this.savedSlot = ((PlayerInventoryAccessor)this.mc.field_1724.method_31548()).getSelectedSlot();
                        }

                        int axeSlot = this.findAxe();
                        if (axeSlot != -1) {
                           ((PlayerInventoryAccessor)this.mc.field_1724.method_31548()).setSelectedSlot(axeSlot);
                        }

                        this.lastAttackMs = System.currentTimeMillis();
                        this.lastSwapMs = System.currentTimeMillis();
                     }

                  } else {
                     if (System.currentTimeMillis() - this.lastAttackMs >= (long)this.attackDelay.getValue() || this.savedSlot == -1) {
                        AttackValidator.tryAttack(this.mc, "combat.attack.autoshieldbreak.recode");
                        if (this.autoStun.isEnabled()) {
                           AttackValidator.tryAttack(this.mc, "combat.attack.autoshieldbreak.recode.stun");
                        }

                        this.lastCpsMs = System.currentTimeMillis();
                        this.lastAttackMs = System.currentTimeMillis();
                        this.lastSwapBackMs = System.currentTimeMillis();
                        breakingShield = false;
                     }

                  }
               } else {
                  if (System.currentTimeMillis() - this.lastReactionMs < (long)(this.reactionDelay.getValue() / 2.0D)) {
                     this.lastReactionMs = System.currentTimeMillis();
                  }

               }
            }
         }
      }
   }

   public void onDisable() {
      if (this.mc.field_1724 != null && this.savedSlot != -1 && this.revertSlot.isEnabled()) {
         ((PlayerInventoryAccessor)this.mc.field_1724.method_31548()).setSelectedSlot(this.savedSlot);
      }

      this.savedSlot = -1;
      breakingShield = false;
      super.onDisable();
   }

   private boolean isLookingAtHitbox(class_1657 target) {
      if (this.mc.field_1724 == null) {
         return false;
      } else {
         class_239 hitResult = this.mc.field_1765;
         if (hitResult instanceof class_3966) {
            class_3966 entityHit = (class_3966)hitResult;
            if (entityHit.method_17782() == target) {
               double requiredInside = class_3532.method_15350(this.hitboxAccuracy.getValue(), 0.0D, 1.0D);
               if (requiredInside <= 0.0D) {
                  return true;
               }

               class_243 eyePos = this.mc.field_1724.method_33571();
               class_238 box = target.method_5829();
               class_243 center = box.method_1005();
               double dx = center.field_1352 - eyePos.field_1352;
               double dy = center.field_1351 - eyePos.field_1351;
               double dz = center.field_1350 - eyePos.field_1350;
               double horizontalDist = Math.sqrt(dx * dx + dz * dz);
               float targetYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
               float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontalDist)));
               double yawDiff = (double)Math.abs(class_3532.method_15393(this.mc.field_1724.method_36454() - targetYaw));
               double pitchDiff = (double)Math.abs(class_3532.method_15393(this.mc.field_1724.method_36455() - targetPitch));
               double safeDist = Math.max(horizontalDist, 0.001D);
               double halfWidth = Math.max(box.method_17939(), box.method_17941()) * 0.5D;
               double yawHalfSpan = Math.toDegrees(Math.atan2(Math.max(halfWidth, 0.001D), safeDist));
               double yawInside = 1.0D - Math.min(1.0D, yawDiff / Math.max(yawHalfSpan, 0.001D));
               double safeVertical = Math.max(horizontalDist, 0.001D);
               double halfHeight = box.method_17940() * 0.5D;
               double pitchHalfSpan = Math.toDegrees(Math.atan2(Math.max(halfHeight, 0.001D), safeVertical));
               double pitchInside = 1.0D - Math.min(1.0D, pitchDiff / Math.max(pitchHalfSpan, 0.001D));
               return Math.min(yawInside, pitchInside) >= requiredInside;
            }
         }

         return false;
      }
   }
}
