package sl.selene.module.impl.movement;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import sl.selene.event.EventInit;
import sl.selene.event.lifecycle.ClientTickEvent;
import sl.selene.event.player.AttackEvent;
import sl.selene.module.api.Category;
import sl.selene.module.api.IModule;
import sl.selene.module.api.Module;
import sl.selene.module.api.setting.Setting;
import sl.selene.module.api.setting.impl.BooleanSetting;
import sl.selene.module.api.setting.impl.SliderSetting;
import sl.selene.module.impl.combat.CombatUtil;

@IModule(
   name = "WTap",
   description = "Taps the forward key after attacking to reset sprint",
   category = Category.Movement,
   bind = -1
)
@Environment(EnvType.CLIENT)
public class WTap extends Module {

   public static SliderSetting chance = new SliderSetting("Chance", 100.0F, 0.0F, 100.0F, 1.0F, true);
   public static SliderSetting tapTicks = new SliderSetting("Tap Ticks", 2.0F, 1.0F, 6.0F, 1.0F, false);
   public static SliderSetting delayTicks = new SliderSetting("Delay Ticks", 1.0F, 1.0F, 4.0F, 1.0F, false);
   public static BooleanSetting onlyOnGround = new BooleanSetting("Only On Ground", false);
   public static BooleanSetting onlyWeapon = new BooleanSetting("Only Weapon", true);

   private int pendingDelay;
   private int tapRemaining;
   private boolean wasHeld;

   public WTap() {
      this.addSettings(new Setting[] { chance, tapTicks, delayTicks, onlyOnGround, onlyWeapon });
   }

   @Override
   public String getArrayListSuffix() {
      return fmt(tapTicks.get());
   }

   @EventInit
   public void onAttack(AttackEvent event) {
      if (mc.player == null || event.isCancelled()) {
         return;
      }
      if (onlyOnGround.get() && !mc.player.isOnGround()) {
         return;
      }
      if (onlyWeapon.get() && !CombatUtil.isWeaponType(mc.player.getMainHandStack(), "Melee")) {
         return;
      }
      if (Math.random() * 100.0 >= chance.get()) {
         return;
      }
      if (pendingDelay <= 0 && tapRemaining <= 0) {
         pendingDelay = Math.max(1, Math.round(delayTicks.get()));
      }
   }

   @EventInit
   public void onTick(ClientTickEvent event) {
      if (mc.player == null) {
         return;
      }

      if (pendingDelay > 0) {
         pendingDelay--;
         if (pendingDelay > 0) {
            return;
         }
         double vx = mc.player.getVelocity().x;
         double vz = mc.player.getVelocity().z;
         if (vx * vx + vz * vz <= 0.0025D) {
            return;
         }
         wasHeld = mc.options.forwardKey.isPressed();
         if (wasHeld) {
            mc.options.forwardKey.setPressed(false);
         }
         tapRemaining = Math.max(1, Math.round(tapTicks.get()));
         return;
      }

      if (tapRemaining > 0) {
         tapRemaining--;
         if (tapRemaining <= 0 && wasHeld && !mc.options.forwardKey.isPressed()) {
            mc.options.forwardKey.setPressed(true);
         }
      }
   }

   @Override
   public void onDisable() {
      pendingDelay = 0;
      tapRemaining = 0;
      if (mc.player != null && wasHeld && !mc.options.forwardKey.isPressed()) {
         mc.options.forwardKey.setPressed(true);
      }
      wasHeld = false;
      super.onDisable();
   }
}